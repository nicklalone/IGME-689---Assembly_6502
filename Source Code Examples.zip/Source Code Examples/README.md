Compiler with dasm - http://www.johnidouglas.com.br/installing-dasm-version-2-20-11-assembly-compiler-in-linux-with-apt-get/ 

hello.asm - https://gist.github.com/chesterbr/5864935
vcs.h - http://www.alienbill.com/2600/101/bin/vcs.h

6502.lang - GEdit syntax highlighting Atari 2600 6502 development http://atariage.com/forums/topic/145412-gedit-syntax-highlighting/ 
Paste in /GEdit/../language-specs' folder. 
Select 'Atari 2600' under 'View->Highlight Mode->Sources'.

Line command compiler with dasm: dasm <file-name>.asm -f3 -o<file-name>.bin where 

